<?php include("include/header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- FontAwesome for the icons used in features -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
        
        <!-- Features Section S -->
    <link rel="stylesheet" href="index.css">

    <!-- Enhanced UI Styles -->
    <style>
        /* Hero Section Styling */
        .hero {
            background: linear-gradient(135deg, #0d6efd 0%, #0dcaf0 100%);
            color: white;
            padding: 100px 20px;
            text-align: center;
        }tyling */
        .features {
            padding: 80px 0;
            background-color: #f8f9fa;
        }
        
        .custom-card {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
            padding: 30px 20px;
            background: white;
        }
        
        .custom-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important;
        }
        
        .icon-wrapper {
            width: 70px;
            height: 70px;
            background-color: rgba(13, 110, 253, 0.1);
            color: #0d6efd;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 20px;
        }

        /* Footer Styling */
        .footer {
            background-color: #212529;
            color: #f8f9fa;
            padding: 60px 0 20px 0;
        }
        
        .footer-links a {
            color: #adb5bd;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }
        
        .footer-links a:hover {
            color: #0d6efd;
        }
        
        .footer-Contact p {
            color: #adb5bd;
            margin-bottom: 10px;
        }

        /* Social Icons */
        .social-icons {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .social-icons a:hover {
            background-color: #0d6efd;
            transform: scale(1.1);
        }
        
        .social-icons svg {
            width: 18px;
            height: 18px;
        }

        /* Hide the empty <i> tags if they clash with svgs */
        .social-icons i.fab {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 40px;
            border-top: 1px solid rgba(255,255,255,0.1);
            color: #adb5bd;
            font-size: 0.9rem;
        }
    </style>
</head>

<body>
    
<!-- Bootstrap JS (bundle includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" xintegrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<!-- Hero Section -->
<section class="hero shadow-sm">
    <div class="container">
        <h1 class="display-4 fw-bold mb-3">Welcome to Digital Library</h1>
        <p class="lead mb-4 opacity-75">Manage books, members, and borrowing records efficiently.</p>
        <button class="btn btn-light btn-lg rounded-pill px-5 fw-bold text-primary shadow">Explore Books</button>
    </div>
</section>

<!-- Features -->
<section class="features">
    <div class="container">
        <div class="row g-4 text-center">
            
            <div class="col-md-6 col-lg-3">
                <div class="card custom-card shadow-sm">
                    <div class="card-body">
                        <div class="icon-wrapper">
                            <i class="fas fa-book"></i>
                        </div>
                        <h3 class="h5 fw-bold">Book Management</h3>
                        <p class="text-muted">Add, update, and organize library books easily.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card custom-card shadow-sm">
                    <div class="card-body">
                        <div class="icon-wrapper">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="h5 fw-bold">Member Records</h3>
                        <p class="text-muted">Maintain complete information of all members.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card custom-card shadow-sm">
                    <div class="card-body">
                        <div class="icon-wrapper">
                            <i class="fas fa-exchange-alt"></i>
                        </div>
                        <h3 class="h5 fw-bold">Issue & Return</h3>
                        <p class="text-muted">Track borrowed books and return dates accurately.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card custom-card shadow-sm">
                    <div class="card-body">
                        <div class="icon-wrapper">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3 class="h5 fw-bold">Reports</h3>
                        <p class="text-muted">Generate useful reports for library performance.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- Main Section -->
<main class="container py-5 my-4 text-center">
    <h1 class="display-6 fw-bold text-dark mb-4">buy our books</h1>
    <a></a>
</main>

<!-- Dropdown Script -->
<script>
    function toggleMenu() {
        document.querySelector(".dropdown").classList.toggle("active");
    }

    document.addEventListener("click", function(e) {
        if (!e.target.closest(".dropdown")) {
            document.querySelector(".dropdown")?.classList.remove("active");
        }
    });
</script>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row g-5">
            <!-- Library info -->
            <div class="col-lg-4 col-md-6 footer-about">
                <h2 class="h4 fw-bold mb-4">Library Management</h2>
                <p class="text-muted lh-lg">Manage books, members, and records efficiently with our smart digital library system.</p>
            </div>
            
            <!-- Quick Links -->
            <div class="col-lg-4 col-md-6 footer-links">
                <h3 class="h5 fw-bold mb-4">Quick Links</h3>
                <a href="#">Home</a>
                <a href="#">Catalog</a>
                <a href="#">About</a>
                <a href="#">Contact Us</a>
            </div>
            
            <!-- Contact + Social -->
            <div class="col-lg-4 col-md-12 footer-Contact">
                <h3 class="h5 fw-bold mb-4">Contact Us</h3>
                <p><i class="fas fa-envelope me-2"></i> Email: gautami5686@gmail.com</p>
                <p><i class="fas fa-phone-alt me-2"></i> Phone: +91 8957198329</p>
                
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                        <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
                        </svg>
                    </i></a>
                    <a href="#"><i class="fab fa-twitter">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                        <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334q.002-.211-.006-.422A6.7 6.7 0 0 0 16 3.542a6.7 6.7 0 0 1-1.889.518 3.3 3.3 0 0 0 1.447-1.817 6.5 6.5 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.32 9.32 0 0 1-6.767-3.429 3.29 3.29 0 0 0 1.018 4.382A3.3 3.3 0 0 1 .64 6.575v.045a3.29 3.29 0 0 0 2.632 3.218 3.2 3.2 0 0 1-.865.115 3 3 0 0 1-.614-.057 3.28 3.28 0 0 0 3.067 2.277A6.6 6.6 0 0 1 .78 13.58a6 6 0 0 1-.78-.045A9.34 9.34 0 0 0 5.026 15"/>
                        </svg>
                    </i></a>
                    <a href="#"><i class="fab fa-instagram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                        <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
                        </svg>
                    </i></a>
                    <a href="#"><i class="fab fa-linkedin-in">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
                        <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854zm4.943 12.248V6.169H2.542v7.225zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248S2.4 3.226 2.4 3.934c0 .694.521 1.248 1.327 1.248zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016l.016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225z"/>
                        </svg>
                    </i></a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            © 2026 Library Management System | All Rights Reserved
        </div>
    </div>
</footer>

</body>
</html>