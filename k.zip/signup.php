<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Library Signup</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
  <div class="signup-container">
    <div class="signup-box">
      <h2>Signup</h2>
      <form id="signup-form">
        <input type="Id" name="id" placeholder="User ID:" ><br>
        <input type="text" name="name" placeholder="Full Name:" ><br>
        <input type="Mobile No." name="mobile" placeholder="Mobile No.:" ><br>
        <input type="Date of Birth" name="date of birth" placeholder="DOB:"><br>
        <input type="email" name="email" placeholder="Email Address:"><br>
        <input type="password" name="password" placeholder="Password:"><br>
        <select name="role">
          <option value="Department">Department</option>
          <option value="Computer science & Engineering">Computer Science & Engineering</option>
          <option value="Civil Engineering">Civil Engineering</option>
         <option value="Mechenical Engineering">Mechenical Engineering</option>
         <option value="Electrical Engineering">Electrical Engineering</option>
        </select>
      </form>
    </div>
  </div>
</body>
