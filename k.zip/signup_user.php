
<!DOCTYPE html>
<html>
<head>
    <title>User Signup</title>
    <style>
        body { font-family: Arial; background: #f4f6fa; }
        .box {
            width: 350px;
            margin: 80px auto;
            padding: 20px;
            background: white;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #0a1f44; }
        input, button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }
        button {
            background: #0a1f44;
            color: white;
            border: none;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Signup</h2>
    <form method="post" action="#">
        <input type="text" placeholder="Name" required>
        <input type="number" placeholder="ID" required>
        <input type="date" placeholder="D.O.B" required>
        <input type="number" placeholder="Mobile No." required>
        <input type="email" placeholder="Email" required>
        <input type="password" placeholder="Password" required>
        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>
