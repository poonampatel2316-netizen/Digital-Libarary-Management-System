<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Dashboard</title>
  <!-- Link external CSS -->
  <link rel="stylesheet" href="user dashboard.css">
</head>
<body>
  <div class="sidebar">
    <h2>Library</h2>
    <a href="#">Dashboard</a>
    <a href="#">Books</a>
    <a href="#">Members</a>
    <a href="#">Issued</a>
    <a href="#">Settings</a>
  </div>

  <div class="main">
    <div class="header">
      <h1>User Dashboard</h1>
      <span id="date"></span>
    </div>

    <div class="cards">
      <div class="card">
        <h3>Total Books</h3>
        <p id="books">1200</p>
      </div>
      <div class="card">
        <h3>Members</h3>
        <p id="members">350</p>
      </div>
      <div class="card">
        <h3>Issued Books</h3>
        <p id="issued">220</p>
      </div>
    </div>

    <div class="actions">
      <button onclick="issueBook()">Issue Book</button>
      <button onclick="returnBook()">Return Book</button>
      <button onclick="addMember()">Add Member</button>
    </div>
  </div>

  <!-- Link external JS -->
  <script>
    // Display current date
document.getElementById("date").textContent = new Date().toDateString();

// Example interactive functions
function issueBook() {
  let issued = document.getElementById("issued");
  issued.textContent = parseInt(issued.textContent) + 1;
  alert("Book issued successfully!");
}

function returnBook() {
  let issued = document.getElementById("issued");
  if (parseInt(issued.textContent) > 0) {
    issued.textContent = parseInt(issued.textContent) - 1;
    alert("Book returned successfully!");
  } else {
    alert("No books to return!");
  }
}

function addMember() {
  let members = document.getElementById("members");
  members.textContent = parseInt(members.textContent) + 1;
  alert("New member added!");
}

  </script>
</body>
</html>
