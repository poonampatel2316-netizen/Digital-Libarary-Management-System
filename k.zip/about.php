<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Library Management System</title>
  <link rel="stylesheet" href="about.css">
</head>
<body>
  <header class="header">
    <div class="logo">📚 LMS</div>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html" class="active">About</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>

  <section class="hero">
    <h1> Our Library Management System</h1>
    <p>Empowering readers with technology, efficiency, and accessibility.</p>
  </section>

  <section class="about-content">
    <h2>Who We Are</h2>
    <p>
      We are a team of innovators passionate about making libraries smarter.  
      Our Library Management System is designed to simplify book management, enhance user experience, and promote a culture of reading in the digital age.
    </p>

    <div class="features">
      <div class="feature-card">
        <h3>🔍 Smart Search</h3>
        <p>Find books instantly with advanced search and filters.</p>
      </div>
      <div class="feature-card">
        <h3>📊 Analytics</h3>
        <p>Track borrowing trends and library performance with detailed reports.</p>
      </div>
      <div class="feature-card">
        <h3>💡 Innovation</h3>
        <p>We integrate modern tools to keep libraries future-ready.</p>
      </div>
    </div>

    <button id="visionBtn">Our Vision</button>
    <div id="visionText" class="hidden">
      🌟 To create a digital ecosystem where knowledge flows freely,  
      and every reader feels empowered to learn and grow.
    </div>
  </section>

  <footer>
    <p>&copy; 2026 Library Management System | All Rights Reserved</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
