<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Library Management System</title>
  <link rel="stylesheet" href="contact.css">
</head>
<body>
  <header class="header">
    <div class="logo">📚 LMS</div>
    <nav>
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
      <a href="contact.html" class="active">Contact</a>
    </nav>
  </header>

  <section class="hero contact-hero">
    <h1>Contact Us</h1>
    <p>We’re here to help you anytime.</p>
  </section>

  <section class="contact-section">
    <div class="contact-info glass-card">
      <h2>Address</h2>
      <p>123 Knowledge Street, Lucknow, India</p>
      <h2>Phone</h2>
      <p>+91 98765 43210</p>
      <h2>Email</h2>
      <p>support@lms.com</p>
    </div>

    <div class="contact-form glass-card">
      <h2>Send Us a Message</h2>
      <form id="contactForm">
        <input type="text" id="name" placeholder="Your Name" required>
        <input type="email" id="email" placeholder="Your Email" required>
        <textarea id="message" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
      <p id="formResponse" class="hidden">✅ Thank you! We’ll get back to you soon.</p>
    </div>
  </section>

  <footer>
    <p>&copy; 2026 Library Management System | Designed with Excellence</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
